# NEAT_schema

NEAT schema defines the schema in the form of a [YAML file](https://github.com/Knowledge-Graph-Hub/NEAT_schema/blob/main/src/linkml/NEAT_schema.yaml) for data going into graph ML pipelines (specifically [NEAT](https://github.com/Knowledge-Graph-Hub/NEAT)). This project itself is generated using the command `linkml-ws new` derived from the [linkML](https://github.com/linkml/linkml) project.

[Documentation](https://knowledge-graph-hub.github.io/NEAT_schema/)
