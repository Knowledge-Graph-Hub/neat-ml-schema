# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['neat_schema', 'neat_schema.datamodel']

package_data = \
{'': ['*']}

install_requires = \
['linkml-runtime>=1.1.24,<2.0.0', 'pytest>=7.1.2,<8.0.0', 'tox>=3.25.0,<4.0.0']

extras_require = \
{':extra == "docs"': ['linkml>=1.2.11,<2.0.0']}

setup_kwargs = {
    'name': 'neat-schema',
    'version': '0.1.0',
    'description': 'Enter description of your project here',
    'long_description': None,
    'author': 'Harshad Hegde',
    'author_email': 'hhegde@lbl.gov',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://knowledge-graph-hub.github.io/NEAT_schema/',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
