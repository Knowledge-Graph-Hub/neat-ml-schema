
# Slot: classifier_name


Name of the classifier.

URI: [https://w3id.org/neat/classifier__classifier_name](https://w3id.org/neat/classifier__classifier_name)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Classifier](Classifier.md)
