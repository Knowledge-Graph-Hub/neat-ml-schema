
# Slot: parameters


Parameters to be passed for building classifier.

URI: [https://w3id.org/neat/classifier__parameters](https://w3id.org/neat/classifier__parameters)


## Domain and Range

None &#8594;  <sub>0..1</sub> [ClassifierParams](ClassifierParams.md)

## Parents


## Children


## Used by

 * [Classifier](Classifier.md)
