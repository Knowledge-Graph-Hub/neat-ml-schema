
# Slot: patience


Number of epochs with no improvement after which training will be stopped.

URI: [https://w3id.org/neat/classifierCallback__patience](https://w3id.org/neat/classifierCallback__patience)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Integer](types/Integer.md)

## Parents


## Children


## Used by

 * [ClassifierCallback](ClassifierCallback.md)
