
# Slot: callbacks


Callbacks.

URI: [https://w3id.org/neat/classifierCallbackContainer__callbacks](https://w3id.org/neat/classifierCallbackContainer__callbacks)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [ClassifierCallback](ClassifierCallback.md)

## Parents


## Children


## Used by

 * [ClassifierCallbackContainer](ClassifierCallbackContainer.md)
