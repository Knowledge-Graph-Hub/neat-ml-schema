
# Slot: data


Input data for pipeline.

URI: [https://w3id.org/neat/graphDataConfiguration__data](https://w3id.org/neat/graphDataConfiguration__data)


## Domain and Range

None &#8594;  <sub>0..1</sub> [TrainValidData](TrainValidData.md)

## Parents


## Children


## Used by

 * [GraphDataConfiguration](GraphDataConfiguration.md)
