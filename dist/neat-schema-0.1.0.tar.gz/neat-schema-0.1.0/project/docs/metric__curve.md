
# Slot: curve


Area under curve (AUC) to be calculated.

URI: [https://w3id.org/neat/metric__curve](https://w3id.org/neat/metric__curve)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Metric](Metric.md)
