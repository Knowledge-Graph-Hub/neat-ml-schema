
# Slot: optimizer


Optimizer function to be used during classifier training.

URI: [https://w3id.org/neat/tFKerasParams__optimizer](https://w3id.org/neat/tFKerasParams__optimizer)


## Domain and Range

None &#8594;  <sub>0..1</sub> [optimizer_enum](optimizer_enum.md)

## Parents


## Children


## Used by

 * [TFKerasParams](TFKerasParams.md)
