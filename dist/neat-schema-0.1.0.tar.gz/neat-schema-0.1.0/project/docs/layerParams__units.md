
# Slot: units




URI: [https://w3id.org/neat/layerParams__units](https://w3id.org/neat/layerParams__units)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Integer](types/Integer.md)

## Parents


## Children


## Used by

 * [LayerParams](LayerParams.md)
