
# Slot: sklearn_params


Parameters specific to sklearn.

URI: [https://w3id.org/neat/classifierParams__sklearn_params](https://w3id.org/neat/classifierParams__sklearn_params)


## Domain and Range

None &#8594;  <sub>0..1</sub> [SkLearnParams](SkLearnParams.md)

## Parents


## Children


## Used by

 * [ClassifierParams](ClassifierParams.md)
