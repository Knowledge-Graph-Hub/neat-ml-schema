
# Slot: train_data


Positive and negative graph data for ML training.

URI: [https://w3id.org/neat/trainValidData__train_data](https://w3id.org/neat/trainValidData__train_data)


## Domain and Range

None &#8594;  <sub>0..1</sub> [PosNegData](PosNegData.md)

## Parents


## Children


## Used by

 * [TrainValidData](TrainValidData.md)
