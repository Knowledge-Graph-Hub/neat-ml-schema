
# Slot: tsne_filename


File name for the TSNE plot.

URI: [https://w3id.org/neat/embeddingsConfig__tsne_filename](https://w3id.org/neat/embeddingsConfig__tsne_filename)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [EmbeddingsConfig](EmbeddingsConfig.md)
