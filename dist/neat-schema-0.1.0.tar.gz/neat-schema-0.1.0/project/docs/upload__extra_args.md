
# Slot: extra_args


Extra keyword arguments (**kwargs).

URI: [https://w3id.org/neat/upload__extra_args](https://w3id.org/neat/upload__extra_args)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Upload](Upload.md)
