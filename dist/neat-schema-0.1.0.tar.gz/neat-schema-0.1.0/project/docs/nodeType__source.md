
# Slot: source


Source node(s).

URI: [https://w3id.org/neat/nodeType__source](https://w3id.org/neat/nodeType__source)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [NodeType](NodeType.md)
