
# Enum: edge_method_enum


Enums containing possible values for node edge methods.

URI: [https://w3id.org/neat/edge_method_enum](https://w3id.org/neat/edge_method_enum)


## Other properties

|  |  |  |
| --- | --- | --- |

## Permissible Values

| Text | Description | Meaning | Other Information |
| :--- | :---: | :---: | ---: |
| Average |  |  |  |
| Hadamard |  |  |  |
| Sum |  |  |  |
| L1 |  |  |  |
| L2 |  |  |  |
| AbsoluteL1 |  |  |  |

