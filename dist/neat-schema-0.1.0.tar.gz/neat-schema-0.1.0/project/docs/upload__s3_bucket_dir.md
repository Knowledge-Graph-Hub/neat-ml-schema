
# Slot: s3_bucket_dir


Bucket path.

URI: [https://w3id.org/neat/upload__s3_bucket_dir](https://w3id.org/neat/upload__s3_bucket_dir)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Upload](Upload.md)
