
# Slot: random_state


Random seed.

URI: [https://w3id.org/neat/skLearnParams__random_state](https://w3id.org/neat/skLearnParams__random_state)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Integer](types/Integer.md)

## Parents


## Children


## Used by

 * [SkLearnParams](SkLearnParams.md)
