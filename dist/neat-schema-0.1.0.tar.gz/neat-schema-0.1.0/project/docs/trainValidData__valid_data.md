
# Slot: valid_data


Positive and negative graph data for ML validation.

URI: [https://w3id.org/neat/trainValidData__valid_data](https://w3id.org/neat/trainValidData__valid_data)


## Domain and Range

None &#8594;  <sub>0..1</sub> [PosNegData](PosNegData.md)

## Parents


## Children


## Used by

 * [TrainValidData](TrainValidData.md)
