
# Slot: outfile


File path for saving results.

URI: [https://w3id.org/neat/applyTrainedModel__outfile](https://w3id.org/neat/applyTrainedModel__outfile)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ApplyTrainedModel](ApplyTrainedModel.md)
