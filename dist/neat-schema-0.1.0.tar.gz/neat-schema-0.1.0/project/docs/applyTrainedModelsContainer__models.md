
# Slot: models


Models that need to be used for link prediction.

URI: [https://w3id.org/neat/applyTrainedModelsContainer__models](https://w3id.org/neat/applyTrainedModelsContainer__models)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [ApplyTrainedModel](ApplyTrainedModel.md)

## Parents


## Children


## Used by

 * [ApplyTrainedModelsContainer](ApplyTrainedModelsContainer.md)
