
# Slot: max_iter


Maximum iterations.

URI: [https://w3id.org/neat/skLearnParams__max_iter](https://w3id.org/neat/skLearnParams__max_iter)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Integer](types/Integer.md)

## Parents


## Children


## Used by

 * [SkLearnParams](SkLearnParams.md)
