
# Slot: tf_keras_params


Parameters specific to Tensorflow/Keras

URI: [https://w3id.org/neat/classifierParams__tf_keras_params](https://w3id.org/neat/classifierParams__tf_keras_params)


## Domain and Range

None &#8594;  <sub>0..1</sub> [TFKerasParams](TFKerasParams.md)

## Parents


## Children


## Used by

 * [ClassifierParams](ClassifierParams.md)
