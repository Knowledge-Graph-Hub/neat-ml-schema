
# Slot: monitor


Quantity to be monitored.

URI: [https://w3id.org/neat/classifierCallback__monitor](https://w3id.org/neat/classifierCallback__monitor)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ClassifierCallback](ClassifierCallback.md)
