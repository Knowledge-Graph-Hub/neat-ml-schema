
# Slot: rate




URI: [https://w3id.org/neat/layerParams__rate](https://w3id.org/neat/layerParams__rate)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Float](types/Float.md)

## Parents


## Children


## Used by

 * [LayerParams](LayerParams.md)
