
# Slot: layers_config


Configuration for instantiating layers for neural networks.

URI: [https://w3id.org/neat/tFKerasParams__layers_config](https://w3id.org/neat/tFKerasParams__layers_config)


## Domain and Range

None &#8594;  <sub>0..1</sub> [LayerContainer](LayerContainer.md)

## Parents


## Children


## Used by

 * [TFKerasParams](TFKerasParams.md)
