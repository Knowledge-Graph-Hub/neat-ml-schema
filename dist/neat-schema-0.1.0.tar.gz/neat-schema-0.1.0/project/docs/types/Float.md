
# Type: float


A real number that conforms to the xsd:float specification

URI: [linkml:Float](https://w3id.org/linkml/Float)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **float** |
