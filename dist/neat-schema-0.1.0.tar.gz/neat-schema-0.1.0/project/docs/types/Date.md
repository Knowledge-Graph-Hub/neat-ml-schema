
# Type: date


a date (year, month and day) in an idealized calendar

URI: [linkml:Date](https://w3id.org/linkml/Date)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **XSDDate** |
| Representation | | str |
