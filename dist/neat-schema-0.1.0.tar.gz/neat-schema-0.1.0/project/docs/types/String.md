
# Type: string


A character string

URI: [linkml:String](https://w3id.org/linkml/String)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **str** |
