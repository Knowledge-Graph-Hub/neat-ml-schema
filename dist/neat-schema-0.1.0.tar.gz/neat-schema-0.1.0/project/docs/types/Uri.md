
# Type: uri


a complete URI

URI: [linkml:Uri](https://w3id.org/linkml/Uri)

|  |  |  |
| --- | --- | --- |
| Root (builtin) type | | **URI** |
| Representation | | str |
