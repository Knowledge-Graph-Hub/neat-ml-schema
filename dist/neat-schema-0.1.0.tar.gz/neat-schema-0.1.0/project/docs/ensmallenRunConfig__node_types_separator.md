
# Slot: node_types_separator


The node types separator.

URI: [https://w3id.org/neat/ensmallenRunConfig__node_types_separator](https://w3id.org/neat/ensmallenRunConfig__node_types_separator)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [EnsmallenRunConfig](EnsmallenRunConfig.md)
