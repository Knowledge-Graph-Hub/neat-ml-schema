
# Slot: parameters




URI: [https://w3id.org/neat/layer__parameters](https://w3id.org/neat/layer__parameters)


## Domain and Range

None &#8594;  <sub>0..1</sub> [LayerParams](LayerParams.md)

## Parents


## Children


## Used by

 * [Layer](Layer.md)
