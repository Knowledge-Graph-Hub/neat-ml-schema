
# Slot: activation


Activation layer type

URI: [https://w3id.org/neat/layerParams__activation](https://w3id.org/neat/layerParams__activation)


## Domain and Range

None &#8594;  <sub>0..1</sub> [activation_enum](activation_enum.md)

## Parents


## Children


## Used by

 * [LayerParams](LayerParams.md)
