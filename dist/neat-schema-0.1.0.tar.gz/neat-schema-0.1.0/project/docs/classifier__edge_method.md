
# Slot: edge_method


Edge method.

URI: [https://w3id.org/neat/classifier__edge_method](https://w3id.org/neat/classifier__edge_method)


## Domain and Range

None &#8594;  <sub>0..1</sub> [edge_method_enum](edge_method_enum.md)

## Parents


## Children


## Used by

 * [Classifier](Classifier.md)
