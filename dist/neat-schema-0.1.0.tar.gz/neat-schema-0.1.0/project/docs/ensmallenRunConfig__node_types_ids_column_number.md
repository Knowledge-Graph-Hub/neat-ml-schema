
# Slot: node_types_ids_column_number


Node type ID column number.

URI: [https://w3id.org/neat/ensmallenRunConfig__node_types_ids_column_number](https://w3id.org/neat/ensmallenRunConfig__node_types_ids_column_number)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Integer](types/Integer.md)

## Parents


## Children


## Used by

 * [EnsmallenRunConfig](EnsmallenRunConfig.md)
