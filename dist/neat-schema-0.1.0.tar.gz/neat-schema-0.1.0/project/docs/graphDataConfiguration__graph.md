
# Slot: graph


Graph configuration for pipeline

URI: [https://w3id.org/neat/graphDataConfiguration__graph](https://w3id.org/neat/graphDataConfiguration__graph)


## Domain and Range

None &#8594;  <sub>0..1</sub> [EnsmallenRunConfig](EnsmallenRunConfig.md)

## Parents


## Children


## Used by

 * [GraphDataConfiguration](GraphDataConfiguration.md)
