
# Slot: type




URI: [https://w3id.org/neat/metric__type](https://w3id.org/neat/metric__type)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Metric](Metric.md)
