
# Slot: node_embeddings_params


Node embeddings parameters.

URI: [https://w3id.org/neat/embeddingsConfig__node_embeddings_params](https://w3id.org/neat/embeddingsConfig__node_embeddings_params)


## Domain and Range

None &#8594;  <sub>0..1</sub> [NodeEmbeddingsParams](NodeEmbeddingsParams.md)

## Parents


## Children


## Used by

 * [EmbeddingsConfig](EmbeddingsConfig.md)
