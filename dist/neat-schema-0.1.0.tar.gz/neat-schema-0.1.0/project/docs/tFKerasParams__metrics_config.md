
# Slot: metrics_config


Metrics to be calculated after classifier training.

URI: [https://w3id.org/neat/tFKerasParams__metrics_config](https://w3id.org/neat/tFKerasParams__metrics_config)


## Domain and Range

None &#8594;  <sub>0..1</sub> [MetricContainer](MetricContainer.md)

## Parents


## Children


## Used by

 * [TFKerasParams](TFKerasParams.md)
