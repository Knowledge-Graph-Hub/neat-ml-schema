
# Slot: history_filename


Embeddings history file name.

URI: [https://w3id.org/neat/embeddingsConfig__history_filename](https://w3id.org/neat/embeddingsConfig__history_filename)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [EmbeddingsConfig](EmbeddingsConfig.md)
