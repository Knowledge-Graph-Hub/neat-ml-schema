
# Slot: epochs


Number of epochs to run for training.

URI: [https://w3id.org/neat/classifierFitParams__epochs](https://w3id.org/neat/classifierFitParams__epochs)


## Domain and Range

None &#8594;  <sub>0..1</sub> [Integer](types/Integer.md)

## Parents


## Children


## Used by

 * [ClassifierFitParams](ClassifierFitParams.md)
