
# Slot: metrics


A list of metrics need to train a classifier.

URI: [https://w3id.org/neat/metricContainer__metrics](https://w3id.org/neat/metricContainer__metrics)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Metric](Metric.md)

## Parents


## Children


## Used by

 * [MetricContainer](MetricContainer.md)
