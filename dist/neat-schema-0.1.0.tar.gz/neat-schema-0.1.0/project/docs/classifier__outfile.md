
# Slot: outfile


Fie path for saving output.

URI: [https://w3id.org/neat/classifier__outfile](https://w3id.org/neat/classifier__outfile)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Classifier](Classifier.md)
