
# Slot: graph_data


Configuration for graph data.

URI: [https://w3id.org/neat/neatConfiguration__graph_data](https://w3id.org/neat/neatConfiguration__graph_data)


## Domain and Range

None &#8594;  <sub>0..1</sub> [GraphDataConfiguration](GraphDataConfiguration.md)

## Parents


## Children


## Used by

 * [NeatConfiguration](NeatConfiguration.md)
