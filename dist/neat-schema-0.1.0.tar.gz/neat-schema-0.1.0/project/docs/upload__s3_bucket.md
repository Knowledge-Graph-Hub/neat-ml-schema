
# Slot: s3_bucket


Bucket name.

URI: [https://w3id.org/neat/upload__s3_bucket](https://w3id.org/neat/upload__s3_bucket)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Upload](Upload.md)
