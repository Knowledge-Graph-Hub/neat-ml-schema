
# Slot: model_id


Key of the model to be used.

URI: [https://w3id.org/neat/applyTrainedModel__model_id](https://w3id.org/neat/applyTrainedModel__model_id)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ApplyTrainedModel](ApplyTrainedModel.md)
