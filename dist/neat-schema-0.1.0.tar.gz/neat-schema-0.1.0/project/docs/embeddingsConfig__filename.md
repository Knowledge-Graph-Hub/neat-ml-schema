
# Slot: filename


Embeddings file name.

URI: [https://w3id.org/neat/embeddingsConfig__filename](https://w3id.org/neat/embeddingsConfig__filename)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [EmbeddingsConfig](EmbeddingsConfig.md)
