
# Slot: type


Type of layer.

URI: [https://w3id.org/neat/layer__type](https://w3id.org/neat/layer__type)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Layer](Layer.md)
