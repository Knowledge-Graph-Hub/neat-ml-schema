
# Slot: classifiers


Classifier details.

URI: [https://w3id.org/neat/classifierContainer__classifiers](https://w3id.org/neat/classifierContainer__classifiers)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [Classifier](Classifier.md)

## Parents


## Children


## Used by

 * [ClassifierContainer](ClassifierContainer.md)
