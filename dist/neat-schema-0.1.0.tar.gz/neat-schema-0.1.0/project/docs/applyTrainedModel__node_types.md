
# Slot: node_types


Type of nodes.

URI: [https://w3id.org/neat/applyTrainedModel__node_types](https://w3id.org/neat/applyTrainedModel__node_types)


## Domain and Range

None &#8594;  <sub>0..1</sub> [NodeType](NodeType.md)

## Parents


## Children


## Used by

 * [ApplyTrainedModel](ApplyTrainedModel.md)
