
# Slot: callbacks_list


List of callbacks.

URI: [https://w3id.org/neat/classifierFitParams__callbacks_list](https://w3id.org/neat/classifierFitParams__callbacks_list)


## Domain and Range

None &#8594;  <sub>0..1</sub> [ClassifierCallbackContainer](ClassifierCallbackContainer.md)

## Parents


## Children


## Used by

 * [ClassifierFitParams](ClassifierFitParams.md)
