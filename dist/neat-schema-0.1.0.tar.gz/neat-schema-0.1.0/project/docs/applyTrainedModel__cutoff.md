
# Slot: cutoff


Cutoff filter.

URI: [https://w3id.org/neat/applyTrainedModel__cutoff](https://w3id.org/neat/applyTrainedModel__cutoff)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [ApplyTrainedModel](ApplyTrainedModel.md)
