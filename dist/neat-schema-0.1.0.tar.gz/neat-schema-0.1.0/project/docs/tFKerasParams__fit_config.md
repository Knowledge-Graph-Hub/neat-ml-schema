
# Slot: fit_config


Configuration for model fitting.

URI: [https://w3id.org/neat/tFKerasParams__fit_config](https://w3id.org/neat/tFKerasParams__fit_config)


## Domain and Range

None &#8594;  <sub>0..1</sub> [ClassifierFitParams](ClassifierFitParams.md)

## Parents


## Children


## Used by

 * [TFKerasParams](TFKerasParams.md)
