
# Slot: destination


Destination node(s).

URI: [https://w3id.org/neat/nodeType__destination](https://w3id.org/neat/nodeType__destination)


## Domain and Range

None &#8594;  <sub>0..\*</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [NodeType](NodeType.md)
