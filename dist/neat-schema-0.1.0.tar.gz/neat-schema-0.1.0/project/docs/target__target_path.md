
# Slot: target_path


File path for saving results.

URI: [https://w3id.org/neat/target__target_path](https://w3id.org/neat/target__target_path)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [Target](Target.md)
