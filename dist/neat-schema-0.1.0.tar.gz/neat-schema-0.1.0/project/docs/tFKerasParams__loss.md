
# Slot: loss


Loss function.

URI: [https://w3id.org/neat/tFKerasParams__loss](https://w3id.org/neat/tFKerasParams__loss)


## Domain and Range

None &#8594;  <sub>0..1</sub> [String](types/String.md)

## Parents


## Children


## Used by

 * [TFKerasParams](TFKerasParams.md)
